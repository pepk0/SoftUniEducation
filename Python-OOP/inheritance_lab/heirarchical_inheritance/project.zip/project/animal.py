class Animal:
    @staticmethod
    def eat() -> str:
        return "eating..."
